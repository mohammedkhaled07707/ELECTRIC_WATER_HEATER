/*
 * LM35.h
 *
 *  Created on: Oct 21, 2022
 *      Author: Mohammed Khaled,Youssef Khaled,Samir tarek,Mohammed el moez
 */

#ifndef LM35_H_
#define LM35_H_

#include "../STD_TYPES.h"
#include "../MCAL/Register_addresses.h"

void lm35_Init();

void lm35_Read(uint8 *data );




#endif /* LM35_H_ */
