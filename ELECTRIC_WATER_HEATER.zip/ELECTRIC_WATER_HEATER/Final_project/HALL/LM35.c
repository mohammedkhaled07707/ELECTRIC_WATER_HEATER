/*
 * LM35.c
 *
 *  Created on: Oct 21, 2022
 *      Author: Mohammed Khaled,Youssef Khaled,Samir tarek,Mohammed el moez
 */

#include "LM35.h"
#define ADIF 4
#define ADSC 6
void lm35_Init()
{
	DDRA&=~(1<<0); //make PA0 an i/p for ADC
	ADCSRA =0x87; //make ADC enable and ck/128
	ADMUX=0xE0; //adc0 will be left justified
}
void lm35_Read(uint8 *data )
{
	 ADCSRA|=(1<<ADSC);
	 while((ADCSRA&(1<<ADIF))==0);
	 *data=ADCH;
}
